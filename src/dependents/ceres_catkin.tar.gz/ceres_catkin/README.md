ceres catkin wrapper
=====

This repository contains catkin simple files to checkout and build ceres and its dependencies.
In order to use the ceres covariance computation, you must use an PIC version of suitesparse:

* Check out the following repositories:
  * https://github.com/ethz-asl/suitesparse
  * https://github.com/ethz-asl/glog_catkin
  * https://github.com/ethz-asl/gflags_catkin
  * https://github.com/ethz-asl/catkin_simple
